import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;

public class GurukulaTest {


    private WebDriver driver;

    @Before
    public void setup() {

        String pathToChromeDriver = "C:\\Program Files\\Java\\jdk1.8.0_211\\chromedriver_win32\\chromedriver.exe";

        System.setProperty("webdriver.chrome.driver", pathToChromeDriver);

        driver = new ChromeDriver();
    }

    @Test
    public void testNewUserRegister() throws InterruptedException {
        driver.navigate().to("http://localhost:8080/#/");

        driver.manage().window().maximize();

        synchronized(driver)
        { driver.wait(1000);}

        driver.findElement(By.xpath("/html/body/div[3]/div[1]/div/div/div[2]/div/div[2]/a")).click();

        driver.findElement(By.xpath("/html/body/div[3]/div[1]/div/div/div/form/div[1]/input")).sendKeys("user1");

        driver.findElement(By.xpath("/html/body/div[3]/div[1]/div/div/div/form/div[2]/input")).sendKeys("user1@gurukula.com");

        driver.findElement(By.xpath("/html/body/div[3]/div[1]/div/div/div/form/div[3]/input")).sendKeys("Password1");

        driver.findElement(By.xpath("/html/body/div[3]/div[1]/div/div/div/form/div[4]/input")).sendKeys("Password1");

        driver.findElement(By.xpath("/html/body/div[3]/div[1]/div/div/div/form/button")).click();

        synchronized(driver)
        { driver.wait(1000);}

        driver.findElement(By.xpath("/html/body/div[3]/div[1]/div/div/div/div[2]")).getText();

        String message = driver.findElement(By.xpath("/html/body/div[3]/div[1]/div/div/div/div[2]")).getText();

        assertThat(message, is("Registration failed! Please try again later."));
    }

    @Test
    public void testLoginWithAdminUser() throws InterruptedException {
        driver.navigate().to("http://localhost:8080/#/");

        driver.manage().window().maximize();

        synchronized(driver)
        { driver.wait(2000);}

        driver.findElement(By.xpath("/html/body/div[3]/div[1]/div/div/div[2]/div/div[1]/a")).click();

        driver.findElement(By.xpath("//*[@id=\"username\"]")).sendKeys("admin");

        driver.findElement(By.xpath("//*[@id=\"password\"]")).sendKeys("admin");

        driver.findElement(By.xpath("//html/body/div[3]/div[1]/div/div/div/form/button")).click();

        synchronized(driver)
        { driver.wait(1000);}

        String title = driver.findElement(By.xpath("/html/body/div[3]/div[1]/div/div/div[2]/div/div")).getText();

        assertThat(title, is("You are logged in as user \"admin\"."));

        synchronized(driver)
        { driver.wait(1000);}
    }

    @Test
    public void testUserAdminTasks() throws InterruptedException {
        driver.navigate().to("http://localhost:8080/#/");

        driver.manage().window().maximize();

        synchronized(driver)
        { driver.wait(2000);}

        driver.findElement(By.xpath("/html/body/div[3]/div[1]/div/div/div[2]/div/div[1]/a")).click();

        driver.findElement(By.xpath("//*[@id=\"username\"]")).sendKeys("admin");

        driver.findElement(By.xpath("//*[@id=\"password\"]")).sendKeys("admin");

        driver.findElement(By.xpath("//html/body/div[3]/div[1]/div/div/div/form/button")).click();

        synchronized(driver)
        { driver.wait(1000);}

        String title = driver.findElement(By.xpath("/html/body/div[3]/div[1]/div/div/div[2]/div/div")).getText();

        assertThat(title, is("You are logged in as user \"admin\"."));

        driver.findElement(By.xpath("//*[@id=\"navbar-collapse\"]/ul/li[2]/a/span/span[2]")).click();

        driver.findElement(By.xpath("//*[@id=\"navbar-collapse\"]/ul/li[2]/ul/li[1]/a")).click();

        driver.findElement(By.xpath("//*[@id=\"navbar-collapse\"]/ul/li[2]/a/span/span[2]")).click();

        driver.findElement(By.xpath("//*[@id=\"navbar-collapse\"]/ul/li[2]/ul/li[2]/a/span[2]")).click();

        driver.findElement(By.xpath("//*[@id=\"navbar-collapse\"]/ul/li[3]/a/span/span[2]")).click();

        driver.findElement(By.xpath("//*[@id=\"navbar-collapse\"]/ul/li[3]/ul/li[1]/a/span[2]")).click();

        driver.findElement(By.xpath("/html/body/div[3]/div[1]/div/div/div/form/button")).click();

        synchronized(driver)
        { driver.wait(1000);}

        String Message = driver.findElement(By.xpath("/html/body/div[3]/div[1]/div/div/div/div[1]/strong")).getText();

        assertThat(Message,is("Settings saved!"));
    }


    @After
    public void teardown() {
        driver.close();
    }
}